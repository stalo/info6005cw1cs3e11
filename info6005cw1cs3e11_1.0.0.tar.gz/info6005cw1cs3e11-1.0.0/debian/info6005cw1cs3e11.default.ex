# Defaults for info6005cw1cs3e11 initscript
# sourced by /etc/init.d/info6005cw1cs3e11
# installed at /etc/default/info6005cw1cs3e11 by the maintainer scripts

#
# This is a POSIX shell fragment
#

# Additional options that are passed to the Daemon.
DAEMON_OPTS=""
