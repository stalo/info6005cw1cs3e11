?package(info6005cw1cs3e11):needs="X11|text|vc|wm" section="Applications/see-menu-manual"\
  title="info6005cw1cs3e11" command="/usr/bin/info6005cw1cs3e11"
