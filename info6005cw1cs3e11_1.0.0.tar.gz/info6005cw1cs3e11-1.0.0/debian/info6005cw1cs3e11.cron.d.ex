#
# Regular cron jobs for the info6005cw1cs3e11 package
#
0 4	* * *	root	[ -x /usr/bin/info6005cw1cs3e11_maintenance ] && /usr/bin/info6005cw1cs3e11_maintenance
